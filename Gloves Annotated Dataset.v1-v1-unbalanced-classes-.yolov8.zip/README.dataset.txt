# Gloves Annotated Dataset > v1 -unbalanced classes-
https://universe.roboflow.com/sana-ali/gloves-annotated-dataset

Provided by a Roboflow user
License: Public Domain

Video frames of people with gloved/un-gloved hands.

Classes:
* **gloved**
* **not-gloved**